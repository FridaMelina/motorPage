/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aplicacion1.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author frida
 */
@WebServlet(name = "ServletOperaciones", urlPatterns = {"/ServletOperaciones"})
public class ServletPrueba1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServletPrueba1</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ServletPrueba1 at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Mi Calculadora</title>");            
            out.println("</head>");
            out.println("<body>");
            
            String num1 = request.getParameter("txtnum1");
            String num2 = request.getParameter("txtnum2");
            String btnSuma = request.getParameter("btnSuma");
            String btnResta = request.getParameter("btnResta");
            String btnMulti = request.getParameter("btnMulti");
            String btnDivi = request.getParameter("btnDivi");
            if(btnSuma!=null){
            int suma = Integer.parseInt(num1)+Integer.parseInt(num2);
            out.println("La suma de los dos numeros es: "+suma);
            }
            if(btnResta!=null){
            int resta = Integer.parseInt(num1)-Integer.parseInt(num2);
            out.println("La resta de los dos numeros es: "+resta);
            }
            if(btnMulti!=null){
            int multi = Integer.parseInt(num1)*Integer.parseInt(num2);
            out.println("La multiplicación de los dos numeros es: "+multi);
            }
            if(btnDivi!=null){
            int divi = Integer.parseInt(num1)/Integer.parseInt(num2);
            out.println("La división de los dos numeros es: "+divi);
            }
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
}

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
